app.controller('HomeCtrl', function($scope) {
    $scope.title = 'Página principal!';
});

